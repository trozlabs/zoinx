const { ResponseObj, APIError, Route, Controller } = require('zoinx/core');
const { Filter } = require('zoinx/util');
const _ = require('lodash');
const {VerifyAuth} = require("zoinx/middle");

const routeLabel = 'Ach';

module.exports = class Ach extends Controller {

    route = '/ach';
    routes = [
        new Route({ method: 'post',      path: '/parse',     handler: 'parse',     before: [VerifyAuth] })
    ]

    constructor(config) {
        super(config);
        this.init(this);
    }

    async parse(req, res) {
        let achContents = req.body;

        if (_.isEmpty(achContents)) {
            throw new APIError(400, 'Must provide an ACH body to parse.');
        }

        let useLabel = false;
        if (!_.isEmpty(req.query.useLabel)) {
            try {
                useLabel = JSON.parse(req.query.useLabel.toLowerCase());
            }
            catch (e) {}
        }
        let rtn = await this.service.parseAchContent(achContents, useLabel);
        return rtn;
    }
}
