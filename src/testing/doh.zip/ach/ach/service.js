const { Service, APIError } = require('zoinx/core');
const { Ach } = require('../../integrations/ach');
const _ = require('lodash');

module.exports = class AchService extends Service {

    constructor() {
        super();
    }

    async parseAchContent(achContents, useLabel=false,  logOptions=false) {
        if (_.isEmpty(achContents)) {
            throw new APIError(400, 'Must provide an ACH body to parse.');
        }

        let ach = new Ach(achContents),
            parsed;

        try {
            parsed = await ach.parseAchFile(useLabel);
        }
        catch (e) {
            throw new APIError(400, 'Failed to parse ACH Content.');
        }

        return parsed;
    }

}
