const { RouteDef } = require('zoinx/core');
const path = require('path');

module.exports = class Ach extends RouteDef {

    constructor(app) {
        let routes = {
            Ach: {
                base: '/ach',
                router: path.join(__dirname, './route'),
                enabled: true
            }
        };
        super(app, routes);
    }

};
