module.exports = class NachaStatics {

    static recordTypes = {
        1: {label: 'File Header',       map: 'fileHeaderFields'},
        5: {label: 'Batch Header',      map: 'fileBatchHeaderFields'},
        6: {label: 'Entry Detail',      map: 'fileEntryRecordsFields'},
        7: {label: 'Addenda',           map: 'fileAddendaFields'},
        8: {label: 'Batch Control',     map: 'fileBatchControlFields'},
        9: {label: 'File Control',      map: 'fileTrailerFields'},
        999: {label: 'File Padding',    map: ''}
    }

    static serviceClassCodes = {
        200: {label: 'Mixed Debits and Credits'},
        220: {label: 'Credits Only'},
        225: {label: 'Debits Only'}
    }

    static ddaTransactionCodes = {
        22: {label: 'Credit'},
        23: {label: 'Credit Prenote'},
        27: {label: 'Debit'},
        28: {label: 'Debit Prenote'}
    }

    static savingsTransactionCodes = {
        32: {label: 'Credit'},
        33: {label: 'Credit Prenote'},
        37: {label: 'Debit'},
        38: {label: 'Debit Prenote'}
    }

    //101 103902717 10390271719043016000094101Valley National Bank   Valley National Bank   BILL PMT
    static fileHeaderFields = {
        1: {propName: 'recordTypeCode',            label: 'Record Type Code',           position: 1, length: 1, required: true, content: '1'},
        2: {propName: 'priorityCode',              label: 'Priority Code',              position: 2, length: 2, required: true, content: '01'},
        3: {propName: 'destinationRoutingNumber',  label: 'Destination Routing Number', position: 4, length: 10, required: true, content: 'Bnnnnnnnn'},
        4: {propName: 'originRoutingNumber',       label: 'Origin Routing Number',      position: 14, length: 10, required: true, content: 'Bnnnnnnnn'},
        5: {propName: 'fileCreationDate',          label: 'File Creation Date',         position: 24, length: 6, required: true, content: 'YYMMDD'},
        6: {propName: 'fileCreationTime',          label: 'File Creation Time',         position: 30, length: 4, required: false, content: 'HHMM'},
        7: {propName: 'fileIDModifier',            label: 'File ID Modifier',           position: 34, length: 1, required: true, content: 'A-Z, 0-9'},
        8: {propName: 'recordSize',                label: 'Record Size',                position: 35, length: 3, required: true, content: '094'},
        9: {propName: 'blockingFactor',            label: 'Blocking Factor',            position: 38, length: 2, required: true, content: '10'},
        10: {propName: 'formatCode',               label: 'Format Code',                position: 40, length: 1, required: true, content: '1'},
        11: {propName: 'immediateDestinationName', label: 'Immediate Destination Name', position: 41, length: 23, required: false, content: 'alphanumeric'},
        12: {propName: 'immediateOriginName',      label: 'Immediate Origin Name',      position: 64, length: 23, required: false, content: 'alphanumeric'},
        13: {propName: 'referenceCode',            label: 'Reference Code',             position: 87, length: 8, required: false, content: 'alphanumeric'}
    }

    //5200BILL PAY FEE    BILL PAY FEE        9ZZZZZZZZZPPDBill Pay  0430191904301201103902710000001
    static fileBatchHeaderFields = {
        1: {propName: 'recordTypeCode',            label: 'Record Type Code',           position: 1, length: 1, required: true, content: '5'},
        2: {propName: 'serviceClassCode',          label: 'Service Class Code',         position: 2, length: 3, required: true, content: 'numeric'},
        3: {propName: 'companyName',               label: 'Company Name',               position: 5, length: 16, required: true, content: 'alphanumeric'},
        4: {propName: 'companyDiscretionaryData',  label: 'Company Discretionary Data', position: 21, length: 20, required: false, content: 'alphanumeric'},
        5: {propName: 'companyIdentification',     label: 'Company Identification',     position: 41, length: 10, required: true, content: 'alphanumeric'},
        6: {propName: 'standardEntryClassCode',    label: 'Standard Entry Class Code',  position: 51, length: 3, required: false, content: 'alphanumeric'},
        7: {propName: 'companyEntryDescription',   label: 'Company Entry Description',  position: 54, length: 10, required: true, content: 'alphanumeric'},
        8: {propName: 'companyDescriptiveDate',    label: 'Company Descriptive Date',   position: 64, length: 6, required: true, content: 'alphanumeric'},
        9: {propName: 'effectiveEntryDate',        label: 'Effective Entry Date',       position: 70, length: 6, required: true, content: 'YYMMDD'},
        10: {propName: 'settlementDate',           label: 'Settlement Date (Julian)',   position: 76, length: 3, required: true, content: 'numeric'},
        11: {propName: 'originatorStatusCode',     label: 'Originator Status Code',     position: 79, length: 1, required: false, content: 'alphanumeric'},
        12: {propName: 'originatingDFIIdentification', label: 'Originating DFI Identification', position: 80, length: 8, required: false, content: 'TTTTAAAA'},
        13: {propName: 'batchNumber',               label: 'Batch Number',              position: 88, length: 7, required: false, content: 'numeric'}
    }

    //6271039027171058908          0000000900BILL PAY FEE   Bill Pay Fee          000103902710000001
    static fileEntryRecordsFields = {
        1: {propName: 'recordTypeCode',            label: 'Record Type Code',           position: 1, length: 1, required: true, content: '6'},
        2: {propName: 'transactionCode',           label: 'Transaction Code',           position: 2, length: 2, required: true, content: 'numeric'},
        3: {propName: 'receivingDFIId',            label: 'Receiving DFI Identification', position: 4, length: 8, required: true, content: 'TTTTAAAA'},
        4: {propName: 'checkDigit',                label: 'Check Digit',                position: 12, length: 1, required: true, content: 'numeric'},
        5: {propName: 'dfiAccountNumber',          label: 'DFI Account Number',         position: 13, length: 17, required: true, content: 'alphanumeric'},
        6: {propName: 'amount',                    label: 'Amount',                     position: 30, length: 10, required: true, content: 'currency'},
        7: {propName: 'idNumber',                  label: 'Identification Number',      position: 40, length: 15, required: false, content: 'alphanumeric'},
        8: {propName: 'receivingIndCompName',      label: 'Receiving Individual/Company Name', position: 55, length: 22, required: true, content: 'alphanumeric'},
        9: {propName: 'discretionaryData',         label: 'Discretionary Data',         position: 77, length: 2, required: true, content: 'alphanumeric'},
        10: {propName: 'addendaRecordIndicator',   label: 'Addenda Record Indicator',   position: 79, length: 1, required: true, content: 'numeric'},
        11: {propName: 'traceNumber',   label: 'Trace Number',   position: 80, length: 15, required: true, content: 'numeric'}
    }

    //799R03091000016054988      10391336USE 22 FOR CHECKING ACCOUNT                 103913360000080
    static fileAddendaFields = {
        1: {propName: 'recordTypeCode',            label: 'Record Type Code',           position: 1, length: 1, required: true, content: '7'},
        2: {propName: 'addendaTypeCode',           label: 'Addenda Type Code',          position: 2, length: 2, required: true, content: '05'},
        3: {propName: 'paymentRelatedInfo',        label: 'Payment Related Information',position: 4, length: 80, required: false, content: 'alphanumeric'},
        4: {propName: 'addendaSequenceNumber',     label: 'Addenda Sequence Number',    position: 84, length: 4, required: true, content: 'numeric'},
        5: {propName: 'entryDetailSequenceNumber', label: 'Entry Detail Sequence Number',position: 88, length: 7, required: true, content: 'alphanumeric'}
    }

    // 820000000200207805420000000009000000000009009ZZZZZZZZZ                         103902710000001
    static fileBatchControlFields = {
        1: {propName: 'recordTypeCode',            label: 'Record Type Code',           position: 1, length: 1, required: true, content: '8'},
        2: {propName: 'serviceClassCode',          label: 'Service Class Code',         position: 2, length: 3, required: true, content: 'numeric'},
        3: {propName: 'entryAddendaCount',         label: 'Entry/Addenda Count',        position: 5, length: 6, required: true, content: 'numeric'},
        4: {propName: 'entryHash',                 label: 'Entry Hash',                 position: 11, length: 10, required: true, content: 'numeric'}, //The sum of all the Receiving DFI Identification fields contained within the Entry Detail Records in a batch.
        5: {propName: 'totalDebitEntryAmount',     label: 'Total Debit Entry Amount',   position: 21, length: 12, required: true, content: 'numeric'},
        6: {propName: 'totalCreditEntryAmount',    label: 'Total Credit Entry Amount',  position: 33, length: 12, required: true, content: 'numeric'},
        7: {propName: 'companyIdentification',     label: 'Company Identification',     position: 45, length: 10, required: true, content: 'alphanumeric'},
        8: {propName: 'messageAuthenticationCode', label: 'Message Authentication Code',position: 55, length: 19, required: true, content: 'numeric'},
        9: {propName: 'reserved',                  label: 'Reserved',                   position: 74, length: 6, required: false, content: 'blanks'},
        10: {propName: 'originatingDFIId',         label: 'Originating DFI Identification', position: 80, length: 8, required: true, content: 'numeric'},
        11: {propName: 'batchNumber',              label: 'Batch Number',               position: 88, length: 7, required: true, content: 'numeric'}
    }

    //9000003000002000000090093512439000000002015000000002015
    static fileTrailerFields = {
        1: {propName: 'recordTypeCode',            label: 'Record Type Code',           position: 1, length: 1, required: true, content: '9'},
        2: {propName: 'batchCount',                label: 'Batch Count',                position: 2, length: 6, required: true, content: 'numeric'},
        3: {propName: 'blockCount',                label: 'Block Count',                position: 8, length: 6, required: true, content: 'numeric'},
        4: {propName: 'entryAddendaCount',         label: 'Entry/Addenda Count',        position: 14, length: 8, required: true, content: 'numeric'},
        5: {propName: 'entryHash',                 label: 'Entry Hash',                 position: 22, length: 10, required: true, content: 'hash'},
        6: {propName: 'totalDebit',                label: 'Total Debit Entry Amount',   position: 32, length: 12, required: true, content: 'currency'},
        7: {propName: 'totalCredit',               label: 'Total Credit Entry Amount',  position: 44, length: 12, required: true, content: 'currency'},
        8: {propName: 'reserved',                  label: 'Reserved',                   position: 56, length: 39, required: false, content: 'blank'}
    }

    static achParticipants = {
        'operator': {label: 'ACH Operator', desc: 'A central clearing facility that receives Entries from an ODFI, distributes Entries to the appropriate RDFI, and performs the settlement functions for the financial institutions. There are two ACH Operators: the Federal Reserve Bank and the Electronic Payments Network (The Clearing House). The two operators exchange files between each other as well.'},
        'originator': {label: 'Originator', desc: 'A consumer, business or entity that agrees to initiate transactions into the payment system according to an arrangement with a Receiver. The Originator will obtain authorization from the Receiver to transact against their account.'},
        'odfi': {label: 'Originating Depository Financial Institution (ODFI)', desc: 'A participating financial institution that receives the payment instructions from an Originator and forwards the Entries to the ACH Operator. There is an agreement between the Originator and ODFI that binds them to the Nacha Rules. The ODFI receives ACH Entries from Originators and forwards those entries to the ACH Operator.'},
        'receiver': {label: 'Receiver', desc: 'A consumer, corporation or entity that has authorized an Originator to initiate an ACH Entry to the Receiver’s account with the RDFI.'},
        'rdfi': {label: 'Receiving Depository Financial Institution (RDFI)', desc: 'A participating financial institution that receives ACH Entries from the ACH Operator and posts them to the account of its Receivers.'},
        '3rdPartySender': {label: 'Third-Party Sender', desc: 'A Third-Party Sender, a subset of a Third-Party Service Provider, is an entity that transmits ACH Entries on behalf of Originators that have no contractual agreement with the ODFI.'},
        '3rdPartyServiceProvider': {label: 'Third-Party Service Provider', desc: 'A Third-Party Service Provider performs various ACH network functions on behalf of Originators, ODFIs, and/or RDFIs. These functions can include, but are not limited to, creation of ACH files on behalf of an Originator or ODFI or acting as a sending point or receiving point on behalf of an ODFI or RDFI.'}
    }

    static achTransactionTypes = {
        'achCredits': {label: 'ACH Credits', desc: '"Push" of funds from the Originator\'s account at the ODFI to the Receiver\'s account at the RDFI. A common ACH credit application is direct deposit of payroll.'},
        'achDebits': {label: 'ACH Debits', desc: '"Pull" of funds from the Receiver\'s account at the RDFI to the Originator\'s account at the ODFI. A common ACH debit application is payment of an insurance premium.'},
        'achEntries': {label: 'ACH Entries', desc: 'Categorized as either consumer payments or non-consumer payments, depending on the account type of the Receiver involved in the transaction. As there is no consistent way to know whether an account is coded as a consumer or business account, the burden of proof is on the Originator to ensure the type of account for which they have obtained authorization.'},
        'acctValidation': {label: 'Account Validation', desc: 'There are various methods available to verify an account number is open and accepting transactions, including prenotification entries, or various external services that use various methods to validate an account number and its attributes, such as ownership and address.'},
        'prenotification': {label: 'Prenotification', desc: 'A prenotification is a non-monetary Entry (i.e. no funds move as a result of the transaction) that precedes the first live entry. Apart from the dollar amount and transaction code, the prenotification entry should look identical to the subsequent live-dollar entries. This allows the RDFI to verify the accuracy of the account data. Prenotification entries are optional for all Standard Entry Class (SEC) Codes.'}
    }

    static corporateTransactionTypes = {
        'ccd': {label: 'Corporate Credit or Debit (CCD)', desc: ''},
        'ctx': {label: 'Corporate Trade Exchange (CTX)', desc: ''}
    }

    static consumerTransactionTypes = {
        'ppd': {label: 'Prearranged Payment and Deposit (PPD)', desc: 'A PPD entry is a single-entry or recurring ACH credit or debit sent by an Originator to a consumer account to make or collect a payment, where authorization is obtained in writing.'},
        'web': {label: 'Internet-Initiated/Mobile Entries (WEB)', desc: 'Internet-initiated Entries (WEB) can be either a single entry or a recurring ACH debit that takes place when the consumer’s authorization for a transfer of funds is received via the internet or mobile device.'},
        'tel': {label: 'Telephone Initiated Transactions (TEL)', desc: 'Telephone-initiated Entries (TEL) can be either a single or a recurring ACH debit that occurs when the consumer’s authorization for a transfer of funds is received orally via the telephone.'}
    }


}
