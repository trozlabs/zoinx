const _ = require('lodash');
const { Log } = require('zoinx/log');
const Statics = require('./NachaStatics');

module.exports = class Nacha {

    #fileContents

    #parsedContents = []

    constructor(fileContents) {
        if (_.isEmpty(fileContents) || !_.isString(fileContents)) {
            Log.error('ACH file must have content to parse.');
            return;
        }

        this.#fileContents = fileContents.split('\n');
    }

    async parseAchFile(useLabel=false) {
        let line, lineType;

        if (_.isEmpty(this.#fileContents)) {
            Log.warn(`No file contents to parse.`);
            return;
        }

        try {
            for (let i=0; i<this.#fileContents.length; i++) {
                line = this.#fileContents[i];
                lineType = line.substring(0, 1);
                if (!_.isNaN(parseInt(lineType)) && line.substring(0, 3) !== '999') {
                    lineType = parseInt(lineType);
                    let parsed = await this.#parseLine(line, lineType, useLabel);
                    this.#parsedContents.push(parsed);
                }
            }
        }
        catch (e) {
            Log.error(`Error parsing ach line: ${e}`);
        }

        return this.#parsedContents;
    }

    async #parseLine(line, lineType, useLabel=false) {
        let parsed = {}, fields, fieldCount = 0, parsedValue;

        try {
            fields = Statics[Statics.recordTypes[lineType].map];
            fieldCount = Object.keys(fields).length;
            parsed = {};

            for (let i=1; i<=fieldCount; i++) {
                parsedValue = `${line.substring(fields[i].position-1, (fields[i].position-1 + fields[i].length))}`.trim();
                if (fields[i].content === 'currency') {
                    parsedValue = await this.#convert2Currency(parsedValue);
                }
                else if (fields[i].content === 'numeric') {
                    parsedValue = await this.#convert2Float(parsedValue);
                }

                if (useLabel)
                    parsed[fields[i].label] = parsedValue;
                else
                    parsed[fields[i].propName] = parsedValue;
            }
        }
        catch (e) {
            Log.error(`Error parsing file trailer: ${e}`);
        }

        return parsed;
    }

    async parseFileHeader() {
        let parsed, line;

        try {
            if (this.#fileContents.length > 0) {
                line = this.#fileContents[0];
                parsed = await this.#parseLine(line, 1);
            }
        }
        catch (e) {
            Log.error(`Error parsing file header: ${e}`);
        }

        return parsed;
    }

    async parseFileTrailer() {
        let parsed, line;

        try {
            if (this.#fileContents.length > 0) {
                line = this.#fileContents[this.#fileContents.length-1];
                if (_.isEmpty(line))
                    line = this.#fileContents[this.#fileContents.length-2];
                parsed = await this.#parseLine(line, 9);
            }
        }
        catch (e) {
            Log.error(`Error parsing file trailer: ${e}`);
        }

        return parsed;
    }

    async #convert2Currency(value='') {
        let currencyVal, currencyTmp,
            spliceStart = 10,
            numbRegex = /^\d+\.?\d*$/;

        if (_.isEmpty(value) || !_.isString(value) || !numbRegex.test(value)) {
            Log.warn(`Invalid value to convert to currency`);
            return ;
        }

        try {
            currencyTmp = value.split('');
            if (currencyTmp.length <= spliceStart)
                spliceStart = currencyTmp.length - 2;
            currencyTmp.splice(spliceStart, 0, '.');
            currencyVal = parseFloat(currencyTmp.join(''));
        }
        catch (e) {
            Log.error(`Error converting value to currency: ${e}`);
        }

        return currencyVal;
    }

    async #convert2Float(value) {
        let floatVal, floatTmp,
            numbRegex = /^\d+\.?\d*$/;

        if (_.isEmpty(value) || !_.isString(value) || !numbRegex.test(value)) {
            if (!_.isEmpty(value)) Log.warn(`Invalid value to convert to float: ${value}`);
            return;
        }

        try {
            floatVal = parseFloat(value);
        }
        catch (e) {
            Log.error(`Error converting value to float: ${e}`);
        }

        return floatVal;
    }

}
